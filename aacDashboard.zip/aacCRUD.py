from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username = "aacUser", password = "a123"):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:48710' % (username, password))
        # where xxxx is your unique port number
        self.database = self.client['AAC']
        
    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            created = self.database.animals.insert(data)  # data should be dictionary
            pprint(created)
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
                
    # Read method to implement the R in CRUD.
    def read(self, data):
        if data is not None:
            animalInfoResults = self.database.animals.find_one(data)
            if animalInfoResults != None:
                return True
            else:
                raise Exception("Nothing to find, because the Animal Search parameter is empty") 
        
    # Update method to implement the U in CRUD.
    def update(self, document):
        if document is not None: # data needs to be present and valid
            doc = self.database.animals.update_one(document) # insert document
            return doc
        else:
            raise Exception("Nothing to update here, because update permameter is invalid") # error handle
            
   # Delete method to implement the D in CRUD.
    def delete(self, oldData):
        if oldData is not None: # to make sure that update is valid/ensure that data is update with actual changes/additions
                action = self.database.animals.delete_one(oldData) # to update documents in database
                return action
        else:
            raise Exception("Nothing to delete here, because delete parameter is invalid/null") # error handle